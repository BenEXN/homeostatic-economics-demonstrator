# Licences

Auteur : Benjamin Albouy — © 2026

## Code : licence MIT

Les programmes Python et leurs fichiers de dépendances sont diffusés sous licence MIT (texte intégral dans `LICENSE`) :

- `eh_reproductible.py`
- `controle/controle_ordre_superieur.py`, `controle/requirements.txt`
- `tests/tests_moteur.py`, `tests/test_non_regression.py`

## Données, figures et documents : licence CC BY 4.0

Tous les autres fichiers du dépôt sont diffusés sous licence Creative Commons Attribution 4.0 International (CC BY 4.0) : tableaux CSV (`csv/`), figures (`figures/`), journal et référence d'exécution, sorties attendues, notice d'utilisation, journal des modifications, manifeste, et les deux versions de l'article (`docs/`).

Texte de la licence : https://creativecommons.org/licenses/by/4.0/legalcode.fr

Attribution demandée : Benjamin Albouy, *Mise en calcul d'une architecture biophysique–monétaire sous contraintes : un démonstrateur numérique exploratoire*, V1.1, novembre 2026 (voir `CITATION.cff`).
